export const colors=[
    'red', 'yellow', 'black', 'blue', 'white', 'green', 'brown', 'pink', 'orange'
]